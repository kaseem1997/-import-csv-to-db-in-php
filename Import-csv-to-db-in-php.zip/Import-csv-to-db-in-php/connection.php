<?php
function getdb(){
$servername = "localhost";
$username = "root";
$password = " ";
$db = "testing";

try {
   
    $conn = mysqli_connect($servername, $username, "", $db);
     //echo "Connected successfully"; 
    }
catch(exception $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }
    return $conn;
}
?>

