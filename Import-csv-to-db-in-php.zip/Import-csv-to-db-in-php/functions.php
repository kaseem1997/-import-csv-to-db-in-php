<?php
include('connection.php');
$con = getdb();

   if(isset($_POST["Import"]) == "csv"){	
 
		$filename=$_FILES["file"]["tmp_name"];	
		$mimes = array('application/vnd.ms-excel','text/csv','text/tsv');
		if(in_array($_FILES['file']['type'],$mimes)){

		 if($_FILES["file"]["size"] > 0)
		 {
		  	$file = fopen($filename, "r");
		  	$fp = file($_FILES["file"]["tmp_name"], FILE_SKIP_EMPTY_LINES);
		  	$totalrow = count($fp);
		  	
		  	$i = 0;
	        while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
	         {
	           $sql = "INSERT into employeeinfo (emp_id,price,average) values ('".$getData[0]."','".$getData[1]."','".$getData[2]."')";
	           $result = mysqli_query($con, $sql);
			    // var_dump(mysqli_error_list($con));
			    // exit();
				if(!isset($result))
				{
					echo "<script type=\"text/javascript\">
							alert(\"Invalid File:Please Upload CSV File.\");
							window.location = \"index.php\"
						  </script>";		
				}
				else {
					$i+=1;
					  /*echo "<script type=\"text/javascript\">
						alert(\"CSV File has been successfully Imported.\");					
					</script>";*/
				}
	         }
 				echo "<script type=\"text/javascript\">
						alert(\"total number of row ".$totalrow." Total inserted data". $i." Total faild data ".($totalrow-$i)."\");
							window.location = \"index.php\"
					</script>";
 					//echo "total number of row ".$totalrow." Total inserted data". $i." Total faild data ".($totalrow-$i);die;			
	         fclose($file);	
		 }
		}else{
			echo "<script type=\"text/javascript\">
						alert(\"Upload only csv file.\");
						window.location = \"index.php\"
					</script>";
		}
	}	 
	
	 if(isset($_POST["Export"])){
		 
      header('Content-Type: text/csv; charset=utf-8');  
      header('Content-Disposition: attachment; filename=data.csv');  
      $output = fopen("php://output", "w");  
      fputcsv($output, array('S.No','Emp_ID', 'Price', 'Average'));  
      $query = "SELECT * from employeeinfo ORDER BY emp_id DESC";  
      $result = mysqli_query($con, $query);  
      while($row = mysqli_fetch_assoc($result))  
      {  
           fputcsv($output, $row);  
      }  
      fclose($output);  
 }  
	
function get_all_records(){
    $con = getdb();

    $Sql = "SELECT * FROM employeeinfo";
    $result = mysqli_query($con, $Sql);  

    if (mysqli_num_rows($result) > 0) {
     echo "<div class='table-responsive'><table id='datatableid' class='table table-striped table-bordered'>
     <thead>
     <tr>
     	<th>S.No</th>
     	<th>Employee ID</th>
     	<th>Price</th>
     	<th>Average</th>
      </tr>
      </thead>
    <tbody>";

     while($row = mysqli_fetch_assoc($result)) {


         echo "<tr>
         		<td>" . $row['id']."</td>
         		<td>" . $row['emp_id']."</td>
         		<td>" . $row['price']."</td>
         		<td>" . $row['average']."</td>
                </tr>";
         
     }
     echo "</tbody></table></div>";
	 
} else {
     echo "No data in database";
}
}
?>